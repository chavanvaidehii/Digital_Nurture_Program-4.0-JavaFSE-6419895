public class WordDocument implements Document {
    public void open() {
        System.out.println("Opening a Word document.");
    }
    public void close() {
        System.out.println("Closing the Word document.");
    }
}
