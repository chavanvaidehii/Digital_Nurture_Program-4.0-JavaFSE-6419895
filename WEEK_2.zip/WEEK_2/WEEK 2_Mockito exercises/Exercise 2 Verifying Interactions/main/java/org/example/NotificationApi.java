package org.example;

public interface NotificationApi {
    void sendNotification(String message);
}
