package org.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MathUtilsAaaTest {

    private MathUtils mathUtils;

    @Before
    public void setUp() {
        System.out.println(" Setting up before test...");
        mathUtils = new MathUtils(); // Arrange
    }

    @After
    public void tearDown() {
        System.out.println(" Cleaning up after test...");
        mathUtils = null;
    }

    @Test
    public void testAddition() {
        // Act
        int result = mathUtils.add(10, 5);

        // Assert
        assertEquals("Addition should return correct result", 15, result);
    }

    @Test
    public void testSubtraction() {
        
        int result = mathUtils.subtract(10, 4);

        
        assertEquals("Subtraction should return correct result", 6, result);
    }
}
