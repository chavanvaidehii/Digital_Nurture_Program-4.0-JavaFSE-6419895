package com.cognizant.loan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanApplicationTests {

	@Test
	void contextLoads() {
	}

}
