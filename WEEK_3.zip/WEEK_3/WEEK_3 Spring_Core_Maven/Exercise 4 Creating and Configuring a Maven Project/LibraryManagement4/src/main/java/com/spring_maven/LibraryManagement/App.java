package com.spring_maven.LibraryManagement;

public class App {
    public static void main(String[] args) {
        System.out.println("Library Management App started.");
        System.out.println("Spring setup looks good!");
    }
}
