package com.spring_maven.LibraryManagement;

public class AppTest {
    public static void main(String[] args) {
        App.main(new String[]{});  // Bas App ka main method call kar rahe
    }
}
